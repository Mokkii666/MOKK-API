# mokk-API

### 版权申明：本库使用MIT协议

mokk-api 全称 Modular API Kit for Python with Mokkii （Mokkii的Python模块化API工具包），是一个聚合了大量api的聚合模块。